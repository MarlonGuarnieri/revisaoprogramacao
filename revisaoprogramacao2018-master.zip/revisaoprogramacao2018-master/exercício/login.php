<form action="verifica_login.php" method="post">
    <input type="text" name="login">
    <input type="password" name="senha">
    <input type="submit" value="Enviar">
</form>
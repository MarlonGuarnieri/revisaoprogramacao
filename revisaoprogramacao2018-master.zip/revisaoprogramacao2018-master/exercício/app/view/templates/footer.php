<div style="text-align: center; bottom: 0; width: 110%; background-color: black; color: white; position: fixed; margin: auto; margin-left: -50px">
    Mateus M. Erkmann e Guilherme Cipriano - 3InfoI1
</div>
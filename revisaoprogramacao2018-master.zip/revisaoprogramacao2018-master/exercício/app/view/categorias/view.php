<?php session_start();

require_once "../../model/CategoriaCrud.php";
$catCrud = new CategoriaCrud();
//require_once "Categoria.php"
?>




<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<style type="text/css">
    <!--

    #navbar ul {
        margin: 0;
        padding: 5px;
        list-style-type: none;
        text-align: center;
        background-color: #000;
    }

    #navbar ul li {
        display: inline;
    }

    #navbar ul li a {
        text-decoration: none;
        padding: .2em 1em;
        color: #fff;
        background-color: #000;
    }

    #navbar ul li a:hover {
        color: #000;
        background-color: #fff;
    }

    -->
</style>

<?php require_once '../templates/nav.php' ?>

<table border ="1">
    <tr>
        <th>Nome Categoria</th>
        <th>Descricao Categoria</th>
        <th></th>
        <th></th>

    </tr>

    <?php $ress= $catCrud->getCategorias();
    foreach ($ress as $r):{?>
        <tr>
            <td><?php echo $r->getNome();?></td>
            <td><?php echo $r->getDesc();?></td>
            <td><a href="../../controller/controladorCategoria.php?rota=editar&id=<?php echo $r->getId();?>"><button>Editar</button></a></td>
            <td><a href="../../controller/controladorCategoria.php?rota=excluir&id=<?php echo $r->getId();?>"><button>Excluir</button></a></td>
        </tr>
    <?php } endforeach; ?>
    <tr>
        <td><a href="../../controller/controladorCategoria.php?rota=cadastrar"><button>Adicionar Categoria</button></a></td>
    </tr>

</table>

<a href="../../../index2.php"><button>Voltar</button></a>


<?php require_once '../templates/footer.php' ?>

</body>
</html>
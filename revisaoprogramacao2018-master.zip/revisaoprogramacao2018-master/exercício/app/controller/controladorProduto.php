<?php
    require_once "../model/ProdutoCrud.php";


    if (isset($_GET['rota'])){
        $rota = $_GET['rota'];
    }else{
        $rota = 'index';
    }



function editar($id, $nome, $desc){
    $c = new CategoriaCrud();
    $c->updateCategoria($id, $nome, $desc);
    header('location: ../view/categorias/view.php');
}

function deletar($id){
    $c = new CategoriaCrud();
    $c->deleteCategoria($id);
    header('location:../view/categorias/view.php');
}

function cadastrar($nome, $desc){
    $ca = new Categoria(null,$nome, $desc);
    $c = new CategoriaCrud();
    $c->insertCategoria($ca);
    header('location:../view/categorias/view.php');
}


if ($rota == "index"){
    header('location: ../view/categorias/view.php'); //redirecionar - chamar essa página
}

if ($rota == "editar"){
    header('location: ../view/categorias/viewEditar.php?id='.$_GET['id']);
}

if ($rota == "cadastrar"){
    header('location: ../view/categorias/viewCadastrar.php');
}

if ($rota == "insert"){
    cadastrar($_POST['nome'] , $_POST['desc']);
}

if ($rota == "excluir"){
    deletar($_GET['id']);
}

if ($rota == "update"){
    editar($_GET['id'], $_POST['nome'], $_POST['desc']);
}

if ($rota == "exibir"){
    header('location: view.php');
}